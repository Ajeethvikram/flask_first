from flask import Flask, render_template, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///posts.db'
db = SQLAlchemy(app)

class Register(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    degree = db.Column(db.Text, nullable=False)
    type = db.Column(db.Text, nullable=False)
    gender = db.Column(db.Text, nullable=False)
    clinic_name = db.Column(db.String(20), nullable=False, default='N/A')
    address = db.Column(db.Text, nullable=False)
    district = db.Column(db.Text, nullable=False)
    state = db.Column(db.Text, nullable=False)
    pincode = db.Column(db.Text, nullable=False)
    phone = db.Column(db.Text, nullable=False)
    username = db.Column(db.Text, nullable=False)
    password = db.Column(db.Text, nullable=False)
    email = db.Column(db.Text, nullable=False)
    date_posted = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return 'Registered Therapist ' + str(self.id)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    doc_name = db.Column(db.Text, nullable=False)
    doc_id = db.Column(db.Text, nullable=False)
    date = db.Column(db.Text, nullable=False)
    time = db.Column(db.Text, nullable=False)
    phone = db.Column(db.Text, nullable=False)
    email = db.Column(db.Text, nullable=False)
    date_booked = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return 'Booking Therapist ' + str(self.id)

@app.route('/')
def reg():
    return render_template('register-doctor.html')


@app.route('/register', methods=['GET', 'POST'])
def posts():

    if request.method == 'POST':
        post_name = request.form['name']
        post_degree = request.form['degree']
        post_type = request.form['specialization']
        post_gender = request.form['gender']
        post_clinic_name = request.form['clinic']
        post_address = request.form['address']
        post_district = request.form['city']
        post_state = request.form['state']
        post_pincode = request.form['pincode']
        post_phone = request.form['phone']
        post_username = request.form['username']
        post_password = request.form['password']
        post_email = request.form['email']
        new_post = Register(name=post_name,degree=post_degree,type=post_type,gender=post_gender,clinic_name=post_clinic_name,address=post_address,district=post_district,state=post_state,pincode=post_pincode,phone=post_phone,username=post_username,password=post_password,email=post_email)
        db.session.add(new_post)
        db.session.commit()
        return redirect('/list')
    else:
        all_posts = Register.query.order_by(Register.date_posted).all()
        return render_template('list.html', posts=all_posts)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        detail = Register.query.filter_by(username=request.form['username'],password=request.form['password']).all()
        if detail:
            return redirect('/book_list')
        else:
            return redirect('/')
    else:
        return render_template('login.html')

@app.route('/list')
def list():
    all_posts = Register.query.order_by(Register.date_posted).all()
    return render_template('list.html', posts=all_posts)

@app.route('/list/book/<int:id>', methods=['GET', 'POST'])
def book(id):
    post = Register.query.get_or_404(id)

    if request.method == 'POST':
        post_name = request.form['name']
        post_doc_id=post.id
        post_doc_name=post.name
        post_date = request.form['date']
        post_time = request.form['time']
        post_phone = request.form['phone']
        post_email = request.form['email']
        new_post = Book(name=post_name,doc_name=post_doc_name,doc_id=post_doc_id, date=post_date,time=post_time, phone=post_phone, email=post_email)
        db.session.add(new_post)
        db.session.commit()
        return redirect('/list')
    else:
        return render_template('book.html', post=post)

@app.route('/book_list')
def book_list():
    all_posts = Book.query.order_by(Book.date_booked).all()
    return render_template('book_list.html', posts=all_posts)

if __name__ == "__main__":
    app.run(debug=True)